/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.ijse.layered;

import edu.ijse.layered.view.ItemVIew;

/**
 *
 * @author anjanathrishakya
 */
public class Main {
    public static void main(String[] args) {
        new ItemVIew().setVisible(true);
    }
}
